@extends('layouts.mainlayout')
@section('body')
<div class="row">
    <div class="col-12">
        <h2 class="content-header">Basic Tables </h2>
        <p class="content-sub-header">All table styles are inherited in Bootstrap 4, meaning any nested tables will be styled in the same manner as the
            parent.</p>
    </div>
</div>
@endsection