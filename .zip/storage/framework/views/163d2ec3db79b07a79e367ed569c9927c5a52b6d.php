
<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-12">
        <h2 class="content-header">Basic Tables </h2>
        <p class="content-sub-header">All table styles are inherited in Bootstrap 4, meaning any nested tables will be styled in the same manner as the
            parent.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud_2\resources\views/dashboard.blade.php ENDPATH**/ ?>